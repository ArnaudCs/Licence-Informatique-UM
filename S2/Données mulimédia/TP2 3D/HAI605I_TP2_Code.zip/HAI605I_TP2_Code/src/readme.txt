gMini
Author: Tamy Boubekeur
version: 0.9 (september 2009)

This simple program loas its OFF argument file and display it using
OpenGL 2.0 and simple Phong shader.

This program is free software published under the GNU General Public License (http://www.gnu.org/licenses/gpl.txt).

Compile
-------
Use the makefile to compile under Linux ! Requires OpenGL, GLUT, GLEW
and a graphics card supporting Sader Model 2.0. 

Run
---

cd gmini-sl
./Main <model.off>

Use '?' to print commands. 
A collection of OFF meshes is provided in the 'models' directory.
